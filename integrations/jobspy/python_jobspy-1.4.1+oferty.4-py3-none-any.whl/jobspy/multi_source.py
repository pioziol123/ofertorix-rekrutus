"""One bounded adapter run. Source support is distinct from access permission."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Literal, TypedDict

from pydantic import BaseModel, ConfigDict, Field

from jobspy.bayt import Bayt
from jobspy.bdjobs import BDJobs
from jobspy.glassdoor import Glassdoor
from jobspy.glassdoor.constant import domains
from jobspy.hellowork import HelloWork
from jobspy.http_control import ControlledRequests, RequestPolicy, active_control
from jobspy.integration import RunResult, structured_job
from jobspy.linkedin import LinkedIn
from jobspy.model import Country, DescriptionFormat, Scraper, ScraperInput, Site
from jobspy.naukri import Naukri
from jobspy.ziprecruiter import ZipRecruiter

OtherSource = Literal[
    "linkedin",
    "bayt",
    "glassdoor",
    "zip_recruiter",
    "naukri",
    "bdjobs",
    "hellowork",
    "google",
]
ADAPTERS: dict[str, type[Scraper]] = {
    "linkedin": LinkedIn,
    "bayt": Bayt,
    "glassdoor": Glassdoor,
    "zip_recruiter": ZipRecruiter,
    "naukri": Naukri,
    "bdjobs": BDJobs,
    "hellowork": HelloWork,
}


class ResultBase(TypedDict):
    source: OtherSource
    started_at: datetime
    query: dict[str, object]


class SourceRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    source: OtherSource
    search_term: str = Field(min_length=1, max_length=500)
    location: str | None = Field(default="Poland", max_length=200)
    country_indeed: Country = Country.POLAND
    results_wanted: int = Field(default=50, ge=1, le=100)
    hours_old: int | None = Field(default=None, ge=0)
    is_remote: bool = False
    job_type: None = None
    fetch_description: bool = True
    http: RequestPolicy = Field(default_factory=RequestPolicy)


class SourceResult(RunResult):
    schema_version: Literal[2] = 2  # type: ignore[assignment]
    source: OtherSource  # type: ignore[assignment]
    fork_revision: str = "oferty-contract-2"


def unsupported(request: SourceRequest) -> str | None:
    if request.source == "google":
        return "unsupported_source"
    country = request.country_indeed
    supported = {
        "zip_recruiter": country in (Country.USA, Country.CANADA),
        "glassdoor": country in domains,
        "naukri": country == Country.INDIA,
        "bdjobs": country.value == "bangladesh",
        "hellowork": country == Country.FRANCE,
    }
    return "unsupported_scope" if supported.get(request.source) is False else None


class SafeDiagnostics(logging.Handler):
    def __init__(self) -> None:
        super().__init__(logging.WARNING)
        self.skipped = 0
        self.warned = False
        self.failed = False

    def emit(self, record: logging.LogRecord) -> None:
        self.warned = True
        self.failed |= record.levelno >= logging.ERROR
        self.skipped += int(record.getMessage().startswith("skipping job:"))


def collect_source(request: SourceRequest) -> SourceResult:
    start = datetime.now(timezone.utc)
    base: ResultBase = dict(
        source=request.source, started_at=start, query=request.model_dump(mode="json")
    )
    reason = unsupported(request)
    if reason:
        return SourceResult(
            **base,
            finished_at=datetime.now(timezone.utc),
            status="failed",
            stop_reason=reason,
        )
    scraper = ADAPTERS[request.source]()
    control = ControlledRequests(request.http)
    control.strict_location = request.source == "bayt"
    diagnostics = SafeDiagnostics()
    logger = logging.getLogger("jobspy")
    handlers, propagate, level = logger.handlers[:], logger.propagate, logger.level
    logger.handlers, logger.propagate = [diagnostics], False
    logger.setLevel(logging.WARNING)
    token = active_control.set(control)
    jobs = []
    unexpected = False
    try:
        jobs = scraper.scrape(
            ScraperInput(
                site_name=[Site(request.source)],
                **request.model_dump(exclude={"source", "http"}),
                description_format=DescriptionFormat.PLAIN,
            )
        )
    except Exception:
        unexpected = True
    finally:
        active_control.reset(token)
        try:
            if hasattr(scraper, "session"):
                scraper.session.close()
            control.close()
        except Exception:
            diagnostics.warned = True
        logger.handlers, logger.propagate = handlers, propagate
        logger.setLevel(level)
    missing = sum(not job.description for job in jobs)
    failed = unexpected or diagnostics.failed or bool(scraper.error)
    reason = control.stop_reason or (
        "blocked"
        if control.last_status == 403
        else "unexpected_error"
        if unexpected
        else "adapter_error"
        if failed
        else "result_limit"
        if len(jobs) >= request.results_wanted
        else "unverified"
    )
    status: Literal["failed", "partial", "limited"] = (
        "partial"
        if diagnostics.skipped or (jobs and (failed or missing or diagnostics.warned))
        else "failed"
        if failed or control.stop_reason
        else "limited"
    )
    if jobs and control.stop_reason:
        status = "partial"
    records = []
    for job in jobs:
        record = structured_job(job)
        record["site"] = request.source
        records.append(record)
    return SourceResult(
        **base,
        finished_at=datetime.now(timezone.utc),
        status=status,
        stop_reason=reason,
        request_count=control.request_count,
        skipped_jobs=diagnostics.skipped,
        missing_descriptions=missing,
        warnings=["adapter_warning"] if diagnostics.warned else [],
        jobs=records,
    )
