"""Bounded public HTML reader for Indeed Poland; never falls back to GraphQL."""

from __future__ import annotations

import json
import math
import re
from datetime import date, datetime, timezone
from typing import Literal
from urllib.parse import parse_qs, urlencode, urljoin, urlparse

from bs4 import BeautifulSoup, Tag

from jobspy.http_control import ControlledRequests, RequestStopped
from jobspy.integration import IndeedRequest, RunResult, structured_job
from jobspy.model import CompensationInterval, Country, JobPost, Location

BASE = "https://pl.indeed.com"
KEY = re.compile(r"^[A-Za-z0-9_-]{1,200}$")


class HtmlError(Exception):
    def __init__(self, reason: str, warning: str) -> None:
        self.reason = reason
        self.warning = warning


def text(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    result = BeautifulSoup(value, "html.parser").get_text(" ", strip=True)
    return result or None


def selected(node: Tag | BeautifulSoup, selector: str) -> str | None:
    found = node.select_one(selector)
    return found.get_text(" ", strip=True) or None if found else None


def check_page(html: str) -> BeautifulSoup:
    soup = BeautifulSoup(html, "html.parser")
    title = selected(soup, "title") or ""
    if re.search(
        r"blocked|access denied|just a moment|attention required|captcha", title, re.I
    ) or soup.select_one(
        '#challenge-form, .g-recaptcha, #px-captcha, script[src*="challenges.cloudflare.com"]'
    ):
        raise HtmlError("blocked", "blocked_page")
    if soup.select_one('form[action*="consent"], #consent-page') or re.search(
        r"^consent|zgoda na|privacy consent", title, re.I
    ):
        raise HtmlError("blocked", "consent_required")
    return soup


def job_postings(soup: BeautifulSoup) -> list[dict[str, object]]:
    result: list[dict[str, object]] = []

    def visit(value: object) -> None:
        if isinstance(value, list):
            for item in value:
                visit(item)
        elif isinstance(value, dict):
            kind = value.get("@type")
            if kind == "JobPosting" or isinstance(kind, list) and "JobPosting" in kind:
                result.append(value)
            visit(value.get("@graph"))
            # ItemList may wrap JobPosting records.
            visit(value.get("itemListElement"))
            visit(value.get("item"))

    for script in soup.select('script[type="application/ld+json"]'):
        try:
            visit(json.loads(script.get_text()))
        except (ValueError, TypeError):
            continue
    return result


def job_key(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = urlparse(urljoin(BASE, value))
        port = parsed.port
    except ValueError:
        return None
    if (
        parsed.scheme != "https"
        or parsed.hostname != "pl.indeed.com"
        or parsed.username
        or parsed.password
        or port not in (None, 443)
    ):
        return None
    key = parse_qs(parsed.query).get("jk", [""])[0]
    return key if KEY.fullmatch(key) else None


def listing(html: str) -> tuple[list[JobPost], str | None, int]:
    soup = check_page(html)
    jobs: dict[str, JobPost] = {}
    skipped = 0
    nodes = soup.select('[data-jk], a[href*="viewjob?jk="]')
    for node in nodes:
        key = node.get("data-jk") or job_key(node.get("href"))
        if not isinstance(key, str) or not KEY.fullmatch(key):
            skipped += 1
            continue
        if key in jobs:
            continue
        card = node.find_parent("div", class_="job_seen_beacon") or node
        title = selected(card, 'h2.jobTitle, .jobTitle, [data-testid="job-title"]')
        if title is None:
            title = node.get_text(" ", strip=True) if node.name == "a" else None
        if not title:
            skipped += 1
            continue
        jobs[key] = JobPost(
            id=f"in-{key}",
            job_url=f"{BASE}/viewjob?jk={key}",
            title=title,
            company=selected(card, '[data-testid="company-name"], .companyName'),
            location=Location(
                city=selected(card, '[data-testid="text-location"], .companyLocation')
            ),
        )
    for item in job_postings(soup):
        key = job_key(item.get("url"))
        if key and text(item.get("title")):
            jobs[key] = enrich(
                jobs.get(key)
                or JobPost(
                    id=f"in-{key}",
                    job_url=f"{BASE}/viewjob?jk={key}",
                    title=str(item["title"]),
                ),
                item,
            )
        else:
            skipped += 1
    if not jobs and not skipped:
        empty: object = soup.select_one(
            '#no_results, .no_results, [data-testid="no-results"]'
        )
        empty_text = soup.select_one(
            ".jobsearch-NoResult-messageContainer, #resultsCol"
        )
        empty = empty or (
            empty_text.find(
                string=re.compile(
                    r"(?:nie znaleziono (?:żadnych )?ofert|no jobs found|did not match any jobs)",
                    re.I,
                )
            )
            if empty_text
            else None
        )
        if not empty:
            raise HtmlError("page_error", "parser_error")
    next_node = soup.select_one(
        'a[data-testid="pagination-page-next"], a[rel="next"], a[aria-label="Next Page"], a[aria-label="Następna strona"]'
    )
    next_url = None
    if next_node:
        href = next_node.get("href")
        # Preserve this page before validating the next URL in the collector.
        next_url = (
            urljoin(BASE, href) if isinstance(href, str) else BASE + "/invalid-next"
        )
    return list(jobs.values()), next_url, skipped


def amount(value: object) -> float | None:
    if value is None:
        return None
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value < 0
    ):
        raise ValueError("invalid salary")
    return float(value)


def salary(item: dict[str, object]) -> dict[str, object]:
    evidence = {
        key: item[key] for key in ("baseSalary", "estimatedSalary") if key in item
    }
    if not evidence:
        return {}
    origin = "unknown" if "baseSalary" in evidence else "portal_estimate"
    raw = evidence.get("baseSalary", evidence.get("estimatedSalary"))
    if isinstance(raw, list):
        raw = raw[0] if len(raw) == 1 else None
    if not isinstance(raw, dict) or not isinstance(raw.get("value"), dict):
        raise ValueError("invalid salary")
    value = raw["value"]
    low = amount(value.get("minValue", value.get("value")))
    high = amount(value.get("maxValue", value.get("value")))
    if low is not None and high is not None and low > high:
        raise ValueError("invalid salary range")
    unit = value.get("unitText")
    interval = {
        "YEAR": "yearly",
        "MONTH": "monthly",
        "WEEK": "weekly",
        "DAY": "daily",
        "HOUR": "hourly",
    }.get(str(unit).upper())
    currency = raw.get("currency")
    return dict(
        min_amount=low,
        max_amount=high,
        currency=currency if isinstance(currency, str) else None,
        interval=CompensationInterval(interval) if interval else None,
        salary_origin=origin if low is not None or high is not None else "unknown",
        salary_evidence=evidence,
    )


def enrich(job: JobPost, item: dict[str, object]) -> JobPost:
    values: dict[str, object] = {}
    for key in ("title", "description"):
        if value := text(item.get(key)):
            values[key] = value
    company = item.get("hiringOrganization")
    if isinstance(company, dict) and (name := text(company.get("name"))):
        values["company"] = name
    location = item.get("jobLocation")
    if isinstance(location, list):
        location = location[0] if location else None
    if isinstance(location, dict) and isinstance(location.get("address"), dict):
        address = location["address"]
        country = address.get("addressCountry")
        if isinstance(country, dict):
            country = country.get("name")
        values["location"] = Location(
            city=text(address.get("addressLocality")),
            state=text(address.get("addressRegion")),
            country=text(country),
        )
    posted = item.get("datePosted")
    if isinstance(posted, str):
        try:
            values["date_posted"] = date.fromisoformat(posted[:10])
        except ValueError:
            pass
    if item.get("jobLocationType") == "TELECOMMUTE":
        values["is_remote"] = True
    # No inference about employment contract, gross/net, skill or seniority.
    try:
        values.update(salary(item))
    except ValueError:
        values.update(
            min_amount=None,
            max_amount=None,
            currency=None,
            interval=None,
            salary_origin="unknown",
        )
        values["salary_evidence"] = {
            key: item[key] for key in ("baseSalary", "estimatedSalary") if key in item
        }
    return JobPost.model_validate(
        {**{name: getattr(job, name) for name in JobPost.model_fields}, **values}
    )


def detail(job: JobPost, html: str) -> JobPost:
    soup = check_page(html)
    items = job_postings(soup)
    matching = [
        item for item in items if job_key(item.get("url")) == job_key(job.job_url)
    ]
    if matching:
        job = enrich(job, matching[0])
    elif len(items) == 1 and not items[0].get("url"):
        job = enrich(job, items[0])
    description = selected(soup, "#jobDescriptionText")
    if description:
        job = job.model_copy(update={"description": description})
    if not job.description:
        raise HtmlError("page_error", "detail_error")
    return job


def collect_indeed_html(request: IndeedRequest) -> RunResult:
    started = datetime.now(timezone.utc)
    jobs: dict[str, JobPost] = {}
    warnings: list[str] = []
    skipped = 0
    reason = "exhausted"
    failed = False
    session = ControlledRequests(request.http)

    def fetch(url: str) -> str:
        response = session.get(
            url,
            headers={
                "User-Agent": "oferty-pracy/1.0 (personal job reader)",
                "Accept": "text/html",
            },
        )
        try:
            if response.status_code == 403 or 300 <= response.status_code < 400:
                raise HtmlError("blocked", "blocked_page")
            if response.status_code != 200:
                raise HtmlError("page_error", "http_error")
            return response.text
        finally:
            response.close()

    try:
        if request.country_indeed != Country.POLAND:
            raise HtmlError("unsupported_scope", "unsupported_scope")
        params: dict[str, str | int] = {
            "q": request.search_term,
            "l": request.location or "Polska",
            "start": 0,
        }
        if request.hours_old is not None:
            params["fromage"] = math.ceil(request.hours_old / 24)
        if request.is_remote:
            params["sc"] = "0kf:attr(DSQF7);"
        if request.job_type:
            params["jt"] = request.job_type.value
        url: str | None = f"{BASE}/jobs?{urlencode(params)}"
        visited: set[str] = set()
        while url:
            if url in visited:
                reason = "no_progress"
                break
            parsed = urlparse(url)
            if (
                parsed.scheme != "https"
                or parsed.netloc != "pl.indeed.com"
                or parsed.path not in ("/jobs", "/jobs/")
            ):
                raise HtmlError("page_error", "unsafe_pagination")
            visited.add(url)
            page, next_url, lost = listing(fetch(url))
            skipped += lost
            new = [job for job in page if job.id not in jobs]
            if not new and page:
                reason = "no_progress"
                break
            # Retain all known cards before spending the remaining HTTP budget.
            remaining = request.results_wanted - len(jobs)
            accepted = new[:remaining]
            for job in accepted:
                jobs[str(job.id)] = job
            for job in accepted:
                if job.description:
                    continue
                try:
                    jobs[str(job.id)] = detail(job, fetch(job.job_url))
                except HtmlError as error:
                    warnings.append(error.warning)
                    if error.reason == "blocked":
                        raise
                    failed = True
            if len(jobs) >= request.results_wanted:
                reason = "result_limit"
                break
            url = next_url
    except RequestStopped as error:
        reason = error.reason
        failed = reason in ("rate_limited", "transport_error")
    except HtmlError as error:
        reason = error.reason
        warnings.append(error.warning)
        failed = True
    except Exception:
        reason = "unexpected_error"
        failed = True
    finally:
        session.close()
    for job in jobs.values():
        if job.salary_evidence:
            try:
                salary(job.salary_evidence)
            except ValueError:
                warnings.append("salary_parse_error")
    missing = sum(not job.description for job in jobs.values())
    status: Literal["completed", "limited", "partial", "failed"]
    if failed:
        status = "partial" if jobs else "failed"
        if reason == "exhausted":
            reason = "page_error"
    elif missing or skipped:
        status = "partial"
    elif reason != "exhausted":
        status = "limited"
    else:
        status = "completed"
    return RunResult(
        started_at=started,
        finished_at=datetime.now(timezone.utc),
        query=request.model_dump(mode="json"),
        status=status,
        stop_reason=reason,
        jobs=[structured_job(job) for job in jobs.values()],
        request_count=session.request_count,
        skipped_jobs=skipped,
        missing_descriptions=missing,
        warnings=list(dict.fromkeys(warnings)),
    )
